# Spring Boot Authentication & Authorization System

A comprehensive authentication and authorization system built with Spring Boot featuring user management, role-based access control (RBAC), JWT authentication, API key support, and audit logging.

## Features

- **User Registration & Authentication**
  - Email/Username and password registration
  - Email verification
  - Login with JWT token generation
  - Password reset functionality

- **User Account Management**
  - Profile updates (name, email, password)
  - Account deactivation
  - Profile picture upload

- **Authorization**
  - Role-Based Access Control (RBAC)
  - Permission-based authorization
  - Multiple authentication methods:
    - Username/Password
    - JWT Token
    - API Key

- **Audit Logging**
  - Complete audit trail of user actions
  - Who did what, when
  - IP address and user agent tracking

- **Security Features**
  - Password encryption with BCrypt
  - JWT token with expiration
  - API key generation and management
  - Rate limiting
  - Account lockout after failed attempts

## Tech Stack

- Java 17+
- Spring Boot 3.2+
- Spring Security 6
- Spring Data JPA
- PostgreSQL / MySQL
- JWT (JSON Web Tokens)
- Lombok
- MapStruct
- Swagger/OpenAPI

## Project Structure

```
src/main/java/com/auth/system/
├── config/              # Configuration classes
├── controller/          # REST controllers
├── dto/                # Data Transfer Objects
├── entity/             # JPA entities
├── repository/         # Data access layer
├── service/            # Business logic
├── security/           # Security components
├── exception/          # Custom exceptions
├── audit/              # Audit logging
└── util/               # Utility classes
```

## Getting Started

### Prerequisites

- JDK 17 or higher
- Maven 3.6+
- PostgreSQL 12+ or MySQL 8+

### Installation

1. Clone the repository
2. Configure database in `application.yml`
3. Run `mvn clean install`
4. Run `mvn spring-boot:run`

The application will start on `http://localhost:8080`

## API Documentation

Once running, access Swagger UI at: `http://localhost:8080/swagger-ui.html`

## Default Roles

- ADMIN: Full system access
- USER: Basic user access
- MODERATOR: Moderate content and users

## Environment Variables

```
DB_URL=jdbc:postgresql://localhost:5432/authdb
DB_USERNAME=your_username
DB_PASSWORD=your_password
JWT_SECRET=your-secret-key-min-256-bits
JWT_EXPIRATION=86400000
API_KEY_EXPIRATION=31536000000
```
