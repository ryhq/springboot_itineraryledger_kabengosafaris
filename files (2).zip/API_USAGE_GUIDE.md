# API Usage Guide

## Authentication Methods

This system supports three authentication methods:

### 1. Username/Password Authentication (JWT)
The most common authentication method for users.

**Endpoint:** `POST /api/auth/login`

**Request:**
```json
{
  "usernameOrEmail": "john_doe",
  "password": "securePassword123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "tokenType": "Bearer",
    "userId": 1,
    "username": "john_doe",
    "email": "john@example.com",
    "roles": ["ROLE_USER"],
    "permissions": ["USER_READ"]
  }
}
```

**Usage:** Include the access token in the `Authorization` header:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 2. API Key Authentication
Used for programmatic access and integrations.

**Creating an API Key:**

**Endpoint:** `POST /api/api-keys`

**Headers:**
```
Authorization: Bearer <your-jwt-token>
```

**Request:**
```json
{
  "name": "Production API Key",
  "description": "Key for production server",
  "expirationDays": 365
}
```

**Response:**
```json
{
  "success": true,
  "message": "API key created successfully. Please save it securely as it won't be shown again.",
  "data": {
    "id": 1,
    "name": "Production API Key",
    "key": "sk_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnop",
    "active": true,
    "createdAt": "2024-01-01T10:00:00",
    "expiresAt": "2025-01-01T10:00:00"
  }
}
```

**Usage:** Include the API key in the `X-API-Key` header:
```
X-API-Key: sk_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnop
```

## Complete API Flow

### 1. User Registration

**Endpoint:** `POST /api/auth/register`

**Request:**
```json
{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "securePassword123",
  "firstName": "John",
  "lastName": "Doe",
  "phoneNumber": "+1234567890"
}
```

**Response:**
```json
{
  "success": true,
  "message": "User registered successfully. Please check your email for verification.",
  "data": {
    "userId": 1,
    "username": "john_doe",
    "email": "john@example.com",
    "roles": ["ROLE_USER"]
  }
}
```

### 2. Email Verification

**Endpoint:** `GET /api/auth/verify-email?token={verification-token}`

The verification token is sent to the user's email after registration.

### 3. Login

See Authentication Methods section above.

### 4. Get Current User Profile

**Endpoint:** `GET /api/users/me`

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "phoneNumber": "+1234567890",
    "enabled": true,
    "accountNonLocked": true,
    "roles": ["ROLE_USER"],
    "createdAt": "2024-01-01T10:00:00",
    "lastLoginAt": "2024-01-15T14:30:00"
  }
}
```

### 5. Update Profile

**Endpoint:** `PUT /api/users/me`

**Headers:**
```
Authorization: Bearer <token>
```

**Request:**
```json
{
  "firstName": "John",
  "lastName": "Smith",
  "email": "john.smith@example.com",
  "phoneNumber": "+1234567890"
}
```

### 6. Change Password

**Endpoint:** `PUT /api/users/me/password`

**Headers:**
```
Authorization: Bearer <token>
```

**Request:**
```json
{
  "currentPassword": "oldPassword123",
  "newPassword": "newSecurePassword456"
}
```

### 7. View Audit Logs

**Endpoint:** `GET /api/audit-logs/me?userId={userId}&page=0&size=20`

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "content": [
      {
        "id": 1,
        "userId": 1,
        "username": "john_doe",
        "actionType": "LOGIN",
        "description": "User logged in successfully",
        "ipAddress": "192.168.1.1",
        "status": "SUCCESS",
        "createdAt": "2024-01-15T14:30:00"
      }
    ],
    "totalElements": 50,
    "totalPages": 3,
    "size": 20
  }
}
```

## Role-Based Access Control

### Roles
- **ROLE_USER**: Basic user access
- **ROLE_MODERATOR**: Moderate users and view audit logs
- **ROLE_ADMIN**: Full system access

### Permissions
- **USER_READ**: View user information
- **USER_WRITE**: Modify user information
- **USER_DELETE**: Delete users
- **ROLE_READ**: View roles
- **ROLE_WRITE**: Modify roles
- **AUDIT_READ**: View audit logs
- **SYSTEM_ADMIN**: Full system administration

### Protected Endpoints

Some endpoints require specific roles:

- `GET /api/users/{userId}` - Requires `ROLE_ADMIN`
- `GET /api/audit-logs` - Requires `ROLE_ADMIN` or `ROLE_MODERATOR`

## Security Features

### Account Lockout
After 5 failed login attempts, the account is locked for 15 minutes.

### Token Expiration
- **Access Token**: 24 hours
- **Refresh Token**: 7 days
- **API Key**: 1 year (configurable)

### Password Requirements
- Minimum 8 characters
- Maximum 100 characters
- Should include uppercase, lowercase, numbers, and special characters (recommended)

## Testing with cURL

### Register
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "Password123!",
    "firstName": "Test",
    "lastName": "User"
  }'
```

### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "usernameOrEmail": "testuser",
    "password": "Password123!"
  }'
```

### Get Profile (with JWT)
```bash
curl -X GET http://localhost:8080/api/users/me \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Get Profile (with API Key)
```bash
curl -X GET http://localhost:8080/api/users/me \
  -H "X-API-Key: YOUR_API_KEY"
```

## Error Responses

All errors follow this format:

```json
{
  "success": false,
  "message": "Error description",
  "timestamp": "2024-01-15T14:30:00"
}
```

### Common HTTP Status Codes
- **200 OK**: Request successful
- **201 Created**: Resource created successfully
- **400 Bad Request**: Invalid request data
- **401 Unauthorized**: Authentication required or invalid
- **403 Forbidden**: Insufficient permissions
- **404 Not Found**: Resource not found
- **409 Conflict**: Resource already exists
- **500 Internal Server Error**: Server error

## Best Practices

1. **Never share your API keys** - Treat them like passwords
2. **Use HTTPS in production** - Never send credentials over HTTP
3. **Rotate API keys regularly** - Create new keys and revoke old ones
4. **Store JWT tokens securely** - Use httpOnly cookies or secure storage
5. **Implement rate limiting** - Protect against brute force attacks
6. **Monitor audit logs** - Regularly review for suspicious activity
7. **Use strong passwords** - Follow password complexity requirements
8. **Enable 2FA** - Add an extra layer of security (if implemented)
