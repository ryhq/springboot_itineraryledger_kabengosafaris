# Deployment Guide

## Prerequisites

- JDK 17 or higher
- Maven 3.6 or higher
- PostgreSQL 12+ or MySQL 8+
- SMTP server for email (Gmail, SendGrid, etc.)

## Local Development Setup

### 1. Database Setup

**PostgreSQL:**
```sql
CREATE DATABASE authdb;
CREATE USER authuser WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE authdb TO authuser;
```

**MySQL:**
```sql
CREATE DATABASE authdb;
CREATE USER 'authuser'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON authdb.* TO 'authuser'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Environment Variables

Create a `.env` file or set environment variables:

```bash
export DB_URL=jdbc:postgresql://localhost:5432/authdb
export DB_USERNAME=authuser
export DB_PASSWORD=your_password

# JWT Configuration (generate a secure key)
export JWT_SECRET=$(openssl rand -base64 64 | tr -d '\n')
export JWT_EXPIRATION=86400000
export JWT_REFRESH_EXPIRATION=604800000

# Email Configuration (Gmail example)
export MAIL_HOST=smtp.gmail.com
export MAIL_PORT=587
export MAIL_USERNAME=your-email@gmail.com
export MAIL_PASSWORD=your-app-password

# API Key Configuration
export API_KEY_EXPIRATION=31536000000
```

### 3. Build and Run

```bash
# Clone the repository
cd authentication-system

# Build the project
mvn clean install

# Run the application
mvn spring-boot:run

# Or run the JAR
java -jar target/authentication-system-1.0.0.jar
```

### 4. Verify Installation

The application will start on `http://localhost:8080`

- Health check: `http://localhost:8080/api/actuator/health` (if actuator enabled)
- API documentation: `http://localhost:8080/swagger-ui.html`

## Production Deployment

### Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM eclipse-temurin:17-jdk-alpine
WORKDIR /app
COPY target/authentication-system-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: authdb
      POSTGRES_USER: authuser
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    networks:
      - auth-network

  app:
    build: .
    ports:
      - "8080:8080"
    environment:
      DB_URL: jdbc:postgresql://postgres:5432/authdb
      DB_USERNAME: authuser
      DB_PASSWORD: ${DB_PASSWORD}
      JWT_SECRET: ${JWT_SECRET}
      JWT_EXPIRATION: 86400000
      MAIL_HOST: ${MAIL_HOST}
      MAIL_PORT: ${MAIL_PORT}
      MAIL_USERNAME: ${MAIL_USERNAME}
      MAIL_PASSWORD: ${MAIL_PASSWORD}
    depends_on:
      - postgres
    networks:
      - auth-network

volumes:
  postgres_data:

networks:
  auth-network:
```

Run with Docker Compose:

```bash
docker-compose up -d
```

### Kubernetes Deployment

Create Kubernetes manifests in `k8s/` directory:

**deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: auth-system
spec:
  replicas: 3
  selector:
    matchLabels:
      app: auth-system
  template:
    metadata:
      labels:
        app: auth-system
    spec:
      containers:
      - name: auth-system
        image: your-registry/auth-system:1.0.0
        ports:
        - containerPort: 8080
        env:
        - name: DB_URL
          valueFrom:
            secretKeyRef:
              name: auth-secrets
              key: db-url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: auth-secrets
              key: jwt-secret
```

**service.yaml:**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: auth-system-service
spec:
  selector:
    app: auth-system
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8080
  type: LoadBalancer
```

### Cloud Platform Deployment

#### AWS Elastic Beanstalk

1. Install AWS CLI and EB CLI
2. Initialize EB application:
```bash
eb init -p docker auth-system
eb create auth-system-env
eb deploy
```

#### Google Cloud Platform

```bash
gcloud app deploy
```

#### Azure App Service

```bash
az webapp up --name auth-system --resource-group auth-rg
```

## Security Hardening

### 1. HTTPS Configuration

Add SSL certificate in `application.yml`:

```yaml
server:
  ssl:
    enabled: true
    key-store: classpath:keystore.p12
    key-store-password: ${SSL_KEYSTORE_PASSWORD}
    key-store-type: PKCS12
```

### 2. Database Connection Pooling

```yaml
spring:
  datasource:
    hikari:
      maximum-pool-size: 10
      minimum-idle: 5
      connection-timeout: 30000
```

### 3. Rate Limiting

Add dependencies for rate limiting:

```xml
<dependency>
    <groupId>com.bucket4j</groupId>
    <artifactId>bucket4j-core</artifactId>
    <version>8.1.0</version>
</dependency>
```

### 4. CORS Configuration

Add to `SecurityConfig.java`:

```java
@Bean
public CorsConfigurationSource corsConfigurationSource() {
    CorsConfiguration configuration = new CorsConfiguration();
    configuration.setAllowedOrigins(Arrays.asList("https://yourdomain.com"));
    configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE"));
    configuration.setAllowedHeaders(Arrays.asList("*"));
    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    source.registerCorsConfiguration("/**", configuration);
    return source;
}
```

## Monitoring and Logging

### Add Spring Boot Actuator

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```

Configure in `application.yml`:

```yaml
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
  endpoint:
    health:
      show-details: when-authorized
```

### Add Prometheus Metrics

```xml
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-registry-prometheus</artifactId>
</dependency>
```

## Backup and Recovery

### Database Backup Script

```bash
#!/bin/bash
pg_dump -h localhost -U authuser authdb > backup_$(date +%Y%m%d_%H%M%S).sql
```

### Automated Backups with Cron

```cron
0 2 * * * /path/to/backup-script.sh
```

## Performance Tuning

### JVM Options

```bash
java -Xms512m -Xmx2048m \
     -XX:+UseG1GC \
     -XX:MaxGCPauseMillis=200 \
     -jar app.jar
```

### Database Indexing

Ensure proper indexes are created:

```sql
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);
```

## Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Check database is running
   - Verify credentials
   - Check network connectivity

2. **Email Not Sending**
   - Verify SMTP configuration
   - Check firewall rules
   - Ensure app password is correct (for Gmail)

3. **JWT Token Invalid**
   - Verify JWT_SECRET is set correctly
   - Check token expiration
   - Ensure clock synchronization

### Logs Location

```bash
# View logs
tail -f logs/application.log

# Or if using Docker
docker logs -f container_id
```

## Maintenance

### Update Dependencies

```bash
mvn versions:display-dependency-updates
mvn versions:use-latest-releases
```

### Clean Old Audit Logs

Create a scheduled task to clean logs older than 90 days:

```java
@Scheduled(cron = "0 0 2 * * *")
public void cleanOldAuditLogs() {
    LocalDateTime cutoffDate = LocalDateTime.now().minusDays(90);
    auditLogRepository.deleteByCreatedAtBefore(cutoffDate);
}
```
