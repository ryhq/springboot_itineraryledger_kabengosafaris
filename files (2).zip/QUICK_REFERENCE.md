# Quick Reference Card

## Build & Run
```bash
mvn clean install              # Build project
mvn spring-boot:run           # Run application
java -jar target/*.jar        # Run JAR file
```

## Environment Variables
```bash
DB_URL=jdbc:postgresql://localhost:5432/authdb
DB_USERNAME=authuser
DB_PASSWORD=password
JWT_SECRET=<generate-with-openssl>
MAIL_HOST=smtp.gmail.com
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
```

## Common API Calls

### Register
```bash
POST /api/auth/register
{
  "username": "user",
  "email": "user@example.com",
  "password": "Password123!"
}
```

### Login
```bash
POST /api/auth/login
{
  "usernameOrEmail": "user",
  "password": "Password123!"
}
```

### Get Profile
```bash
GET /api/users/me
Headers: Authorization: Bearer <token>
```

### Update Profile
```bash
PUT /api/users/me
Headers: Authorization: Bearer <token>
{
  "firstName": "John",
  "lastName": "Doe"
}
```

### Change Password
```bash
PUT /api/users/me/password
Headers: Authorization: Bearer <token>
{
  "currentPassword": "old",
  "newPassword": "new"
}
```

### Create API Key
```bash
POST /api/api-keys
Headers: Authorization: Bearer <token>
{
  "name": "My API Key",
  "expirationDays": 365
}
```

### View Audit Logs
```bash
GET /api/audit-logs/me?userId=1&page=0&size=20
Headers: Authorization: Bearer <token>
```

## Database Commands

### PostgreSQL
```bash
psql -U postgres
CREATE DATABASE authdb;
\c authdb
\dt                    # List tables
\d users              # Describe users table
```

### MySQL
```bash
mysql -u root -p
CREATE DATABASE authdb;
USE authdb;
SHOW TABLES;
DESCRIBE users;
```

## Docker Commands
```bash
docker build -t auth-system .
docker run -p 8080:8080 auth-system
docker-compose up -d
docker-compose logs -f
docker-compose down
```

## Key URLs
- Application: http://localhost:8080
- Swagger UI: http://localhost:8080/swagger-ui.html
- API Docs: http://localhost:8080/api-docs
- Health Check: http://localhost:8080/api/actuator/health

## Default Configuration
- JWT Expiration: 24 hours
- Refresh Token: 7 days
- API Key: 1 year
- Max Login Attempts: 5
- Account Lockout: 15 minutes
- Server Port: 8080

## Roles & Permissions
**Roles:**
- ROLE_USER (default)
- ROLE_MODERATOR
- ROLE_ADMIN

**Permissions:**
- USER_READ, USER_WRITE, USER_DELETE
- ROLE_READ, ROLE_WRITE
- AUDIT_READ, SYSTEM_ADMIN

## Authentication Headers
```bash
# JWT Token
Authorization: Bearer eyJhbGciOiJIUz...

# API Key
X-API-Key: sk_ABCDEFGHIJKLMNOPQRSTUVWXYZabc...
```

## Common Errors
| Code | Meaning | Solution |
|------|---------|----------|
| 401 | Unauthorized | Check token/credentials |
| 403 | Forbidden | Insufficient permissions |
| 409 | Conflict | Username/email exists |
| 500 | Server Error | Check logs |

## Useful Commands
```bash
# Generate JWT secret
openssl rand -base64 64

# Check Java version
java -version

# Check Maven version
mvn -version

# View logs
tail -f logs/application.log

# Clean build
mvn clean

# Skip tests
mvn install -DskipTests
```

## Testing with cURL
```bash
# Store token in variable
TOKEN=$(curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"usernameOrEmail":"user","password":"pass"}' \
  | jq -r '.data.accessToken')

# Use token
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:8080/api/users/me
```

## Troubleshooting
```bash
# Check if port is in use
lsof -i :8080

# Kill process on port
kill -9 $(lsof -t -i:8080)

# Check database connection
pg_isready -h localhost -p 5432

# Restart PostgreSQL
sudo systemctl restart postgresql

# View Spring Boot logs
journalctl -u spring-boot-app -f
```
