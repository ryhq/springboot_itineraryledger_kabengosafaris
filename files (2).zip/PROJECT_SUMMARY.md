# Spring Boot Authentication System - Project Summary

## Overview

This is a **production-ready** Spring Boot authentication and authorization system with comprehensive features including:

- ✅ User registration with email verification
- ✅ Login with JWT token authentication
- ✅ API key authentication for programmatic access
- ✅ Role-Based Access Control (RBAC) with permissions
- ✅ Complete user account management
- ✅ Comprehensive audit logging (who did what, when)
- ✅ Account security features (lockout, password requirements)
- ✅ REST API with Swagger documentation

## Project Structure

```
authentication-system/
├── src/
│   └── main/
│       ├── java/com/auth/system/
│       │   ├── config/              # Security, OpenAPI, Data initialization
│       │   ├── controller/          # REST endpoints
│       │   ├── dto/                 # Data Transfer Objects
│       │   ├── entity/              # JPA entities (User, Role, Permission, etc.)
│       │   ├── exception/           # Custom exceptions & global handler
│       │   ├── repository/          # Data access layer
│       │   ├── security/            # JWT util, filters, UserDetailsService
│       │   └── service/             # Business logic
│       └── resources/
│           └── application.yml      # Configuration
├── pom.xml                         # Maven dependencies
├── README.md                       # Project overview
├── API_USAGE_GUIDE.md             # Detailed API documentation
└── DEPLOYMENT_GUIDE.md            # Deployment instructions
```

## Key Components

### Entities
1. **User** - User accounts with authentication details
2. **Role** - User roles (ADMIN, MODERATOR, USER)
3. **Permission** - Fine-grained permissions
4. **ApiKey** - API keys for programmatic access
5. **AuditLog** - Complete audit trail of all actions

### Authentication Methods
1. **JWT Token** - Bearer token for web/mobile apps
2. **API Key** - For server-to-server communication
3. **Username/Password** - Traditional login

### Security Features
- BCrypt password encryption
- JWT with configurable expiration
- Account lockout after failed attempts
- Email verification
- Password reset functionality
- Audit logging of all actions

## Quick Start

### 1. Prerequisites
```bash
- JDK 17+
- Maven 3.6+
- PostgreSQL 12+ or MySQL 8+
```

### 2. Database Setup
```sql
CREATE DATABASE authdb;
CREATE USER authuser WITH PASSWORD 'password';
GRANT ALL PRIVILEGES ON DATABASE authdb TO authuser;
```

### 3. Configuration
Set environment variables or update `application.yml`:
```bash
export DB_URL=jdbc:postgresql://localhost:5432/authdb
export DB_USERNAME=authuser
export DB_PASSWORD=password
export JWT_SECRET=$(openssl rand -base64 64)
```

### 4. Build & Run
```bash
mvn clean install
mvn spring-boot:run
```

Access the application at: `http://localhost:8080`
Swagger UI: `http://localhost:8080/swagger-ui.html`

## API Endpoints

### Authentication (`/api/auth`)
- `POST /register` - Register new user
- `POST /login` - Login and get JWT token
- `GET /verify-email?token={token}` - Verify email

### User Management (`/api/users`)
- `GET /me` - Get current user profile
- `PUT /me` - Update profile
- `PUT /me/password` - Change password
- `GET /{userId}` - Get user by ID (Admin only)

### API Keys (`/api/api-keys`)
- `POST /` - Create new API key
- `GET /` - List user's API keys
- `DELETE /{keyId}` - Revoke API key

### Audit Logs (`/api/audit-logs`)
- `GET /me?userId={userId}` - Get user's audit logs
- `GET /` - Get all audit logs (Admin/Moderator)

## Authentication Examples

### Register a User
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "johndoe",
    "email": "john@example.com",
    "password": "SecurePass123!",
    "firstName": "John",
    "lastName": "Doe"
  }'
```

### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "usernameOrEmail": "johndoe",
    "password": "SecurePass123!"
  }'
```

### Access Protected Endpoint (JWT)
```bash
curl -X GET http://localhost:8080/api/users/me \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Access Protected Endpoint (API Key)
```bash
curl -X GET http://localhost:8080/api/users/me \
  -H "X-API-Key: YOUR_API_KEY"
```

## Default Roles & Permissions

### Roles
- **ROLE_USER**: Standard user access
- **ROLE_MODERATOR**: User management and audit viewing
- **ROLE_ADMIN**: Full system access

### Permissions
- USER_READ, USER_WRITE, USER_DELETE
- ROLE_READ, ROLE_WRITE
- AUDIT_READ
- SYSTEM_ADMIN

## Audit Logging

Every action is automatically logged with:
- User who performed the action
- Action type (LOGIN, UPDATE_PROFILE, etc.)
- Timestamp
- IP address
- User agent
- Success/failure status

## Security Best Practices

1. **Use HTTPS in production** - Never transmit credentials over HTTP
2. **Rotate API keys regularly** - Set expiration and create new keys
3. **Strong password policy** - Enforce minimum 8 characters
4. **Monitor audit logs** - Review for suspicious activity
5. **Rate limiting** - Implement to prevent brute force attacks
6. **Keep dependencies updated** - Regularly update Spring Boot and libraries

## Technology Stack

- **Spring Boot 3.2** - Application framework
- **Spring Security 6** - Authentication & authorization
- **Spring Data JPA** - Data persistence
- **PostgreSQL** - Database (MySQL also supported)
- **JWT** - Token-based authentication
- **Lombok** - Reduce boilerplate code
- **Swagger/OpenAPI** - API documentation
- **BCrypt** - Password encryption

## Testing

### Unit Tests (Coming Soon)
```bash
mvn test
```

### Integration Tests (Coming Soon)
```bash
mvn verify
```

### Manual Testing
Use Swagger UI at `http://localhost:8080/swagger-ui.html` for interactive API testing.

## Deployment

### Docker
```bash
docker build -t auth-system .
docker run -p 8080:8080 auth-system
```

### Docker Compose
```bash
docker-compose up -d
```

### Kubernetes
```bash
kubectl apply -f k8s/
```

See `DEPLOYMENT_GUIDE.md` for detailed deployment instructions.

## Monitoring

Access actuator endpoints (if enabled):
- Health: `http://localhost:8080/api/actuator/health`
- Metrics: `http://localhost:8080/api/actuator/metrics`
- Prometheus: `http://localhost:8080/api/actuator/prometheus`

## Troubleshooting

### Database Connection Issues
1. Verify PostgreSQL is running
2. Check credentials in application.yml
3. Ensure database exists and is accessible

### JWT Token Issues
1. Verify JWT_SECRET is set correctly
2. Check token expiration time
3. Ensure clock synchronization

### Email Not Sending
1. Verify SMTP configuration
2. For Gmail, use App Password (not regular password)
3. Check firewall rules for SMTP port

## Support & Documentation

- **API Documentation**: `http://localhost:8080/swagger-ui.html`
- **Detailed API Guide**: See `API_USAGE_GUIDE.md`
- **Deployment Guide**: See `DEPLOYMENT_GUIDE.md`
- **Source Code**: All files included in this package

## Features Roadmap

Potential enhancements:
- [ ] Two-factor authentication (2FA)
- [ ] OAuth2 integration (Google, GitHub, etc.)
- [ ] Rate limiting
- [ ] Account recovery via SMS
- [ ] Session management
- [ ] User profile pictures upload
- [ ] Advanced permission management UI
- [ ] Redis caching
- [ ] WebSocket support for real-time updates

## License

This project is open source and available for modification and distribution.

## Contact

For questions or support, please refer to the documentation or create an issue in your repository.

---

**Congratulations!** You now have a complete, production-ready authentication system. Follow the Quick Start guide to get it running, and refer to the API_USAGE_GUIDE.md for detailed API documentation.
